package com.example.levantuan.projectfinal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class Link extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_link);


        WebView webManual = (WebView) findViewById(R.id.wvlink);
        webManual.loadUrl("https://www.toronto.ca/services-payments/streets-parking-transportation/applying-for-a-parking-permit/parking-by-laws-regulations/parking-regulations/");
    }

}
