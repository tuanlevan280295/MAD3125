package com.example.levantuan.projectfinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddAddress extends AppCompatActivity implements View.OnClickListener{


    DBHelper db;

    EditText edAddress,edcheck;
    Button btnAddress;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_address);

        db = new DBHelper(this);

        edAddress = (EditText)findViewById(R.id.edADDRESS);
        edAddress.setOnClickListener(this);

        edcheck = (EditText) findViewById(R.id.edcheckCARPLATE);
        edcheck.setOnClickListener(this);

        btnAddress = (Button)findViewById(R.id.btnADDRESS);
        btnAddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String address = edAddress.getText().toString();
                String check = edcheck.getText().toString();

                int checkAdd = edcheck.getText().toString().length();

                if(checkAdd > 0){

                    boolean add = db.addforAdress(edcheck.getText().toString(),edAddress.getText().toString());
                    if((add == true)){

                        Toast.makeText(AddAddress.this,"GO TO <Profile> TO CHECK YOUR DATA",Toast.LENGTH_LONG).show();

                        Intent backProfile = new Intent(AddAddress.this, Profile.class);
                        startActivity(backProfile);
                    } else {
                        Toast.makeText(AddAddress.this, "Something went wrong", Toast.LENGTH_LONG).show();
                    }
                }
                Toast.makeText(AddAddress.this,"You Must enter car plate to update",Toast.LENGTH_LONG).show();

            }
        });


    }
    @Override
    public void onClick(View v) {

    }
}
