package com.example.levantuan.projectfinal;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Date;

public class Payment extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener{
    DatabaseHelper helper;
    DBHelper db;
    RadioButton rdOne,rdThree, rdFive, rdEight;
    TextView textAmount, textCurrent;
    Button btpay;
    EditText edcarplate, edtitle, edFULLNAME,edCARDNUMBER,edCITY, edSECURITYCODE;
    int Money[] = {10, 20 , 30,45};
    String PaymentMethods[] = {"Debit Card","Credit Card", "Master Card"};
    String companyNames[]={"BMW","Audi","Marcedes","Jaguar","Lexus"};
    Spinner  spinPayment,spinCompany;

    String  carPlate, payment, dateTime,company;
    int amount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);


        db = new DBHelper(this);
        helper = new DatabaseHelper(this);

        edSECURITYCODE = (EditText) findViewById(R.id.edSECURITY);
        edSECURITYCODE.setOnClickListener(this);

        edCITY = (EditText) findViewById(R.id.edCITY);

        edCARDNUMBER = (EditText) findViewById(R.id.edCARDNUMBER);
        edCARDNUMBER.setOnClickListener(this);

        edFULLNAME = (EditText) findViewById(R.id.edFULLNAME);
        edFULLNAME.setOnClickListener(this);

        edtitle = (EditText) findViewById(R.id.edtitle);
        edtitle.setOnClickListener(this);

        rdOne = (RadioButton) findViewById(R.id.rdoOne);
        rdOne.setOnClickListener(this);
        rdThree = (RadioButton) findViewById(R.id.rdoThree);
        rdThree.setOnClickListener(this);
        rdFive = (RadioButton) findViewById(R.id.rdoFive);
        rdFive.setOnClickListener(this);
        rdEight = (RadioButton) findViewById(R.id.rdoEight);
        rdEight.setOnClickListener(this);

        textAmount = (TextView) findViewById(R.id.tvAmount);
        textAmount.setText("$" + String.valueOf(Money[0]));

        textCurrent = (TextView) findViewById(R.id.tvcurrent);
        textCurrent.setOnClickListener(this);

        edcarplate = (EditText)findViewById(R.id.edCARDNUMBER);

        Date dt = Calendar.getInstance().getTime();
        textCurrent.setText(dt.toString());


        spinPayment = (Spinner) findViewById(R.id.Spntype);
        ArrayAdapter adaptPayment = new ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                PaymentMethods);
        adaptPayment.setDropDownViewResource(
                android.R.layout.simple_spinner_dropdown_item);

        spinPayment.setAdapter(adaptPayment);
        spinPayment.setOnItemSelectedListener(this);


        spinCompany = (Spinner) findViewById(R.id.edCarcompany);
        ArrayAdapter carAdapter = new ArrayAdapter(this,
        android.R.layout.simple_spinner_item,
                companyNames);
        spinCompany.setAdapter(carAdapter);
        spinCompany.setOnItemSelectedListener(this);

        btpay = (Button) findViewById(R.id.btPAY);
        btpay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insert();
            }
        });


    }

    @Override
    public void onClick(View view) {
        if (rdOne.isChecked()) {
            textAmount.setText("$" + String.valueOf(Money[0]));
        } else if (rdThree.isChecked()) {
            textAmount.setText("$" + String.valueOf(Money[1]));
        } else if (rdFive.isChecked()) {
            textAmount.setText("$" + String.valueOf(Money[2]));
        } else if (rdEight.isChecked()) {
            textAmount.setText("$" + String.valueOf(Money[3]));
        }

        if (view.getId() == btpay.getId()) {
            dateTime = textCurrent.getText().toString();
            edcarplate = (EditText) findViewById(R.id.edCARDNUMBER);
            carPlate = edcarplate.getText().toString();
            String strAmount = textAmount.getText().toString();
            strAmount = strAmount.substring(1);
            amount = Integer.parseInt(strAmount);

            SharedPreferences sp = getSharedPreferences("com.example.levantuan.projectfinal", Context.MODE_PRIVATE);
            SharedPreferences.Editor edit = sp.edit();


            edit.putString("CarPlate",carPlate);
            edit.putString("Company",company);
            edit.putInt("Amount",amount);
            edit.putString("DateTime",dateTime);
            edit.putString("Payment",payment);
            edit.commit();

        }
    }
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
        if (adapterView.getId() == spinPayment.getId()) {
            payment = PaymentMethods[position];
        }
        else if (adapterView.getId() == spinCompany.getId()){
        company = companyNames[position];

    }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
    public void insert() {


        String TITLE = edtitle.getText().toString();
        String SECURITYCODE = edSECURITYCODE.getText().toString();
        String CARCOMPANY = spinCompany.getSelectedItem().toString();
        String CARDTYPE = spinPayment.getSelectedItem().toString();
        String CARDNUMBER = edCARDNUMBER.getText().toString();
        String FULLNAME = edFULLNAME.getText().toString();
        String CITY = edCITY.getText().toString();
        String MONEY = textAmount.getText().toString();
        String CURRENT = textCurrent.getText().toString();


        if (TITLE.equals("") || CARDTYPE.equals("") || CARDNUMBER.equals("") || FULLNAME.equals("")
                || CITY.equals("") || MONEY.equals("") | CURRENT.equals("")| SECURITYCODE.equals("")
                | CARCOMPANY.equals(""))

        {
            Toast.makeText(getApplicationContext(), "Field are empty", Toast.LENGTH_LONG).show();

        }
        else {

                Boolean insert = helper.insertData(TITLE,SECURITYCODE,CARCOMPANY, CARDTYPE, CARDNUMBER, FULLNAME, CITY, MONEY, CURRENT);
                if (insert == true) {
                    Toast.makeText(getApplicationContext(), "Payment Successfully", Toast.LENGTH_LONG).show();
                    Intent gotoHOME = new Intent(Payment.this, Receipt.class);
                    startActivity(gotoHOME);
                }
            }
    }

}
