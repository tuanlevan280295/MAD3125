package com.example.levantuan.projectfinal;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;

public class Register extends AppCompatActivity implements View.OnClickListener{


    DBHelper db;
    TextView dbirth;
    EditText e1,e2,e3,e4,e5,e6,e7;
    Button b1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        db = new DBHelper(this);


        e1 = (EditText)findViewById(R.id.editEMAIL);
        e2 = (EditText)findViewById(R.id.editPASSWORD);
        e3 = (EditText)findViewById(R.id.editCFPASSWORD);
        e4 = (EditText)findViewById(R.id.editNAME);
        e5 = (EditText)findViewById(R.id.editPHONE);
        e6 = (EditText)findViewById(R.id.editCARPLATENUMBER);
        e7 = (EditText)findViewById(R.id.EDADDRESS);



        dbirth = (TextView) findViewById(R.id.txtDATEBIRTH);
        dbirth.setOnClickListener(this);


        b1 = (Button)findViewById(R.id.btnSIGNIN);


        b1.setOnClickListener(this);

        db = new DBHelper(this);

    }

    @Override
    public void onClick(View view) {

        if (view.getId() == b1.getId()){

            insertUser();

        }else if(view.getId() == dbirth.getId()){
            Calendar calendar = Calendar.getInstance();
            new DatePickerDialog(this, datePickerListener, calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH)).show();
        }
    }

    DatePickerDialog.OnDateSetListener datePickerListener = new DatePickerDialog.OnDateSetListener() {
        @Override
        public void onDateSet(DatePicker datePicker, int year, int month, int day) {
            String yy = String.valueOf(year);
            String mm = String.valueOf(month+1);
            String dd = String.valueOf(day);

            if (month < 10){
                mm = "0" + mm;
            }

            if(day < 10){
                dd = "0" + dd;
            }

            dbirth.setText(mm + "-" + dd + "-" + yy);
        }
    };

    private void insertUser(){
        String EMAIL = e1.getText().toString();
        String PASSWORD = e2.getText().toString();
        String cfPASSWORD = e3.getText().toString();
        String NAME = e4.getText().toString();
        String PHONE = e5.getText().toString();
        String CARPLATE = e6.getText().toString();
        String BIRTH = dbirth.getText().toString();
        String ADDRESS = e7.getText().toString();





        if(EMAIL.equals("") || PASSWORD.equals("") || cfPASSWORD.equals("") || NAME.equals("")|| PHONE.equals("")||CARPLATE.equals("")|BIRTH.equals(""))
        {
            Toast.makeText(getApplicationContext(), "Field are empty", Toast.LENGTH_LONG).show();

        }

        else {

            if (PASSWORD.equals(cfPASSWORD)){
                Boolean chkemail = db.chkemail(EMAIL);

                if (chkemail == true){
                    Boolean insert = db.insert(NAME,EMAIL,cfPASSWORD,PASSWORD,PHONE,CARPLATE,BIRTH,ADDRESS);

                    if (insert == true){
                        Toast.makeText(getApplicationContext(),"Registered Successfully",Toast.LENGTH_LONG).show();
                        Intent gotoHOME = new Intent(Register.this, Login.class);
                        startActivity(gotoHOME);
                    }
                }
                else {
                    Toast.makeText(getApplicationContext(),"The Email already exists", Toast.LENGTH_LONG).show();
                }
            }
            Toast.makeText(getApplicationContext(),"Passsword do not match", Toast.LENGTH_LONG).show();
        }
    }
}

