package com.example.levantuan.projectfinal;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class Contact extends AppCompatActivity implements View.OnClickListener {

    Button btnCall, btnSMS, btnEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);
        btnCall = (Button) findViewById(R.id.btCALL);
        btnCall.setOnClickListener(this);

        btnSMS = (Button) findViewById(R.id.btSMS);
        btnSMS.setOnClickListener(this);

        btnEmail = (Button) findViewById(R.id.btEMAIL);
        btnEmail.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        switch (view.getId()){
            case R.id.btCALL:
                makeCall();
                break;
            case R.id.btEMAIL:
                sendEmail();
                break;
            case R.id.btSMS:
                sendSMS();
                break;
        }
    }

    private void makeCall(){
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:6473394749"));

        if (ActivityCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.CALL_PHONE) !=
                PackageManager.PERMISSION_GRANTED)
        {
            Toast.makeText(getApplicationContext(),
                    "Call permission denied",Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(callIntent);
    }

    private void sendEmail(){
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setType("text/plain");

        emailIntent.putExtra(Intent.EXTRA_EMAIL,
                new String[]{"tuanlevan280295@gmail.com"});

        emailIntent.putExtra(Intent.EXTRA_SUBJECT,
                "Test Email");
        emailIntent.putExtra(Intent.EXTRA_TEXT,
                "This is a test message");

        emailIntent.setType("message/rfc822");

        startActivity(Intent.createChooser(emailIntent,
                "Select Email Client"));
    }

    private void sendSMS(){
        Intent smsIntent = new Intent(Intent.ACTION_SENDTO,
                Uri.parse("smsto:6473394749"));
        smsIntent.putExtra("sms_body", "Test message");

        if (ActivityCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.SEND_SMS) !=
                PackageManager.PERMISSION_GRANTED){
            Toast.makeText(getApplicationContext(),
                    "SMS permission denied",Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(smsIntent);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.goback, menu);
        return true;
    }


    /// MENU ACTION
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_goback) {
            Intent goHome = new Intent(getApplicationContext(), Home.class);
            startActivity(goHome);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
