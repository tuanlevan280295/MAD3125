package com.example.levantuan.projectfinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

public class Report extends AppCompatActivity {

    ImageView imspended, imaddaddress,imCheckHours, imlink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        imCheckHours = (ImageView) findViewById(R.id.imCheckHours);
        imCheckHours.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent goCheckHours = new Intent(Report.this, CountTime.class);
                startActivity(goCheckHours);
            }
        });
        imspended = (ImageView) findViewById(R.id.imSpended);
        imspended.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goSpended = new Intent(Report.this, Spended.class);
                startActivity(goSpended);
            }
        });

        imlink = (ImageView) findViewById(R.id.imLink);
        imlink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goLink = new Intent(Report.this, Link.class);
                startActivity(goLink);
            }
        });

        imaddaddress = (ImageView) findViewById(R.id.imUpdateAdress);
        imaddaddress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent goAddAddress = new Intent(Report.this, AddAddress.class);
                startActivity(goAddAddress);
            }
        });



    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.goback, menu);
        return true;
    }


    /// MENU ACTION
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_goback) {
            Intent goHome = new Intent(getApplicationContext(), Home.class);
            startActivity(goHome);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }



}
