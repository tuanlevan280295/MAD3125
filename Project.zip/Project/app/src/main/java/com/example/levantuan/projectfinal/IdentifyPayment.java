package com.example.levantuan.projectfinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class IdentifyPayment extends AppCompatActivity{


    DBHelper db;
    Button btCONFIRM;

    EditText cfEmail, cfCarplate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_identify_payment);

        db = new DBHelper(this);

        cfEmail = (EditText) findViewById(R.id.edEmailPAYMENT);
        cfCarplate = (EditText) findViewById(R.id.edcarplatePAYMENT);


        btCONFIRM = (Button) findViewById(R.id.BTCONFIRMPAYMENT);
        btCONFIRM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = cfEmail.getText().toString();
                String carplate = cfCarplate.getText().toString();


                Boolean check = db.checkEmailandcarplate(email,carplate);
                if (check == true) {


                    Intent goHome = new Intent(IdentifyPayment.this, Payment.class);
                    startActivity(goHome);

                    Toast.makeText(getApplicationContext(), "Successfully Confirm Account", Toast.LENGTH_LONG).show();


                }

                else
                    Toast.makeText(getApplicationContext(), "wrong email or Car Plate Number", Toast.LENGTH_LONG).show();


            }
        });
    }
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.goback, menu);
        return true;
    }


    /// MENU ACTION
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_goback) {
            Intent goHome = new Intent(getApplicationContext(), Home.class);
            startActivity(goHome);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}
