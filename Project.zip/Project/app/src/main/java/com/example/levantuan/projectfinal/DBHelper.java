package com.example.levantuan.projectfinal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


//database user
public class DBHelper extends SQLiteOpenHelper {
    public static final String DATABSE_NAME = "Login.db";

    public DBHelper(Context context) {

        super(context, DATABSE_NAME, null, 1);


    }

    @Override
    public void onCreate(SQLiteDatabase db) {


        db.execSQL("Create table information(name text ,email text primary key, password text,cfpassword,phone text, carplate text,dbirth text, address text)");
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {


        db.execSQL("drop table if exists information");


    }

    //insert values

    public boolean insert(String name, String email1, String password1, String cfpassword, String phone, String carplate, String dbirth,String address) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("name", name);
        contentValues.put("email", email1);
        contentValues.put("password", password1);
        contentValues.put("cfpassword", cfpassword);
        contentValues.put("phone", phone);
        contentValues.put("carplate", carplate);
        contentValues.put("dbirth", dbirth);
        contentValues.put("address", address);


        long ins = db.insert("information", null, contentValues);

        if (ins == -1) return false;
        else return true;

    }


    public Boolean chkemail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from information where email=?", new String[]{email});

        if (cursor.getCount() > 0) return false;
        else return true;
    }

    //checking the email and password
    public Boolean emailPassword(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from information where email=? and password=?", new String[]{email, password});
        if (cursor.getCount() > 0) return true;

        else return false;

    }

    // Coding to identify location of data
    public Cursor getProfiles() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM  information ", null);

        return data;
    }


    //coding for update NAME
    public boolean updateData(String name, String carplate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();


        contentValues.put("carplate", carplate);
        contentValues.put("name", name);

        db.update("information", contentValues, "carplate = ?", new String[]{carplate});

        return true;


    }

    // CHECKING IF CAR PLATE NOT = WITH DATABASE (this method for update)
    public Boolean checkcarplate(String carplate) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from information where carplate=?", new String[]{carplate});

        if (cursor.getCount() > 0) return true;
        else return false;
    }

    //coding for update password
    public boolean updatePassword(String password, String cfpassword, String carplate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        contentValues.put("carplate", carplate);
        contentValues.put("cfpassword", cfpassword);
        contentValues.put("password", password);


        db.update("information", contentValues, "carplate = ?", new String[]{carplate});

        return true;


    }


    //checking email and carplate if not equal with database ( using for identify user payment)
    public Boolean checkEmailandcarplate(String email, String carplate) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("Select * from information where email=? and carplate=?", new String[]{email, carplate});

        if (cursor.getCount() > 0) return true;
        else return false;
    }


    // Add address
    public boolean addforAdress(String carplate, String address) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("carplate", carplate);
        contentValues.put("address", address);

        db.update("information", contentValues, "carplate = ?", new String[]{carplate});

        return true;

    }

}



