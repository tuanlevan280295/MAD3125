package com.example.levantuan.projectfinal;

import android.content.Intent;
import android.database.Cursor;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.HeaderViewListAdapter;
import android.widget.TextView;

public class Home extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

DBHelper db;
    private DrawerLayout drawer;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);



        db = new DBHelper(this);


        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawer = findViewById(R.id.draw_layout);

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);



        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,drawer,toolbar,R.string.navigation_drawer_close,R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
    }

    @Override
    public void onBackPressed() {
        if (drawer.isDrawerOpen(GravityCompat.START)){
            drawer.closeDrawer(GravityCompat.START);
        }
        else {
            super.onBackPressed();
        }

    }

    ///MENU SETTING

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.myhome, menu);
        return true;
    }


    /// MENU ACTION
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_Payment){
                Intent goPayment = new Intent(getApplicationContext(),IdentifyPayment.class);
                startActivity(goPayment);

        return true;

        }
        if (id == R.id.action_changepass) {
            Intent goChangePass = new Intent(getApplicationContext(), UpdatePassword.class);
            startActivity(goChangePass);

            return true;
        }
        if (id == R.id.action_check) {
            //Store data from DATABASE

            Cursor data = db.getProfiles();

            if (data.getCount() == 0){
                display("Error", " No Data Found");
                //message
            }

            StringBuffer buffer = new StringBuffer();
            while (data.moveToNext()){
                buffer.append("Name: \n" + data.getString(0) + "\n");
                buffer.append("Email:  \n" + data.getString(1)+ "\n");
                buffer.append("Password: \n" + data.getString(2)+ "\n");
                buffer.append("Phone: \n" + data.getString(4)+ "\n");
                buffer.append("Carplate: \n" + data.getString(5)+ "\n");
                buffer.append("Date of Birth: \n" + data.getString(6)+ "\n");
                buffer.append("Address: \n" + data.getString(7)+ "\n");
                //display message
                display("MY DATA", buffer.toString());

            }
        }

        return super.onOptionsItemSelected(item);
    }
    // display helping for (MENU ACTION)

    public void display(String title, String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    // Navigation Menu

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_receipt) {
            Intent goReceipt = new Intent(getApplicationContext(),Receipt.class);
            startActivity(goReceipt);

        } else if (id == R.id.nav_location) {

            Intent goLocation = new Intent(getApplicationContext(),Location.class);
            startActivity(goLocation);

        } else if (id == R.id.nav_report) {

            Intent goReport = new Intent(getApplicationContext(),Report.class);
            startActivity(goReport);

        } else if (id == R.id.nav_manual) {
            Intent goManual = new Intent(getApplicationContext(),Manual.class);
            startActivity(goManual);

        } else if (id == R.id.nav_contact) {

            Intent supportIntent = new Intent(getApplicationContext(),Contact.class);
            startActivity(supportIntent);

        } else if (id == R.id.nav_profile) {
            Intent goProfile = new Intent(getApplicationContext(), Profile.class);
            startActivity(goProfile);

        }else if (id == R.id.nav_logout){
            finish();
            Intent welcomeIntent = new Intent(this, Wellcome.class);
            startActivity(welcomeIntent);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.draw_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}

