package com.example.levantuan.projectfinal;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class Manual extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manual);


        WebView webManual = (WebView) findViewById(R.id.webviewManual);
        webManual.loadUrl("file:///android_asset/manual.html");

    }
}
