package com.example.levantuan.projectfinal;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Receipt extends AppCompatActivity {

    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt);

        ListView listView = (ListView) findViewById(R.id.listviewReceipt);


        db = new DatabaseHelper(this);


        // Array removing data from DATABASE

        ArrayList<String> thelist = new ArrayList<>();
        Cursor data = db.getReceiptInformation();

        if (data.getCount() == 0) {
            Toast.makeText(Receipt.this, "The database was empty :(", Toast.LENGTH_LONG).show();
        } else {

            while (data.moveToNext()) {

                thelist.add(data.getString(0));
                thelist.add(data.getString(1));
                thelist.add(data.getString(2));
                thelist.add(data.getString(3));
                thelist.add(data.getString(4));
                thelist.add(data.getString(5));
                thelist.add(data.getString(6));
                thelist.add(data.getString(7));
                thelist.add(data.getString(8));

                ListAdapter listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, thelist);
                listView.setAdapter(listAdapter);


            }


        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.goback, menu);
        return true;
    }


    /// MENU ACTION
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_goback) {
            Intent goHome = new Intent(getApplicationContext(), Home.class);
            startActivity(goHome);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
