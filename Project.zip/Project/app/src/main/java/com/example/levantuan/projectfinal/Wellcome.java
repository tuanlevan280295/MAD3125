package com.example.levantuan.projectfinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Calendar;


public class Wellcome extends AppCompatActivity implements View.OnClickListener{


    TextView tvSinin, tvregister,tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wellcome);

        tv = (TextView)findViewById(R.id.textView);
        tv.setOnClickListener( this);

        String mydate = java.text.DateFormat.getDateInstance().format(Calendar.getInstance().getTime());
        tv.setText(mydate.toString());

        tvSinin = (TextView) findViewById(R.id.tvSIGNIN);
        tvregister = (TextView) findViewById(R.id.tvREGISTER);

        tvregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goRegister = new Intent(Wellcome.this, Register.class);
                startActivity(goRegister);
            }
        });

        tvSinin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goLogin = new Intent(Wellcome.this, Login.class);
                startActivity(goLogin);
            }
        });

    }

    @Override
    public void onClick(View v) {

    }
}
