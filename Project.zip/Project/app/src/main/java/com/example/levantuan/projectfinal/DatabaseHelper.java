package com.example.levantuan.projectfinal;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.EditText;


//this database using for receipt

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_PAYMENT_NAME = "payment.db";
    public static final String PAYMENT_NAME = "payment_data";


    public DatabaseHelper(Context context)
    {
        super(context, DATABASE_PAYMENT_NAME, null   , 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CreateTable = " CREATE TABLE " + PAYMENT_NAME + "(title text,security text,carcompany text, cardtype text , " + " cardnumber integer, fullname text,city text, price text, time text)";
        db.execSQL(CreateTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(" DROP IF TABLE EXISTS " + PAYMENT_NAME);

    }

    // input data into database.
    public boolean insertData(String title,String security, String carcompany,String cardtype, String cardnumber, String fullname, String city, String price, String time){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("title",title);
        contentValues.put("security",security);
        contentValues.put("carcompany",carcompany);
        contentValues.put("cardtype",cardtype);
        contentValues.put("cardnumber",cardnumber);
        contentValues.put("fullname",fullname);
        contentValues.put("city",city);
        contentValues.put("price",price);
        contentValues.put("time",time);

        long result = db.insert(PAYMENT_NAME, null, contentValues);
        if (result == -1){
            return false;
        }else{
            return true;
        }

    }
    // Coding to get price and date.
    public Cursor getspended() {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM " +  PAYMENT_NAME, null);

        return data;
    }


    public Cursor getReceiptInformation(){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor data = db.rawQuery("SELECT * FROM " + PAYMENT_NAME, null);
        return data;
    }

}
