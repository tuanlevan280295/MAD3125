package com.example.levantuan.projectfinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateName extends AppCompatActivity {
    DBHelper db;
    Button btUpdate;
    EditText edCarplate, edNewName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_name);

        db = new DBHelper(this);

        btUpdate = (Button) findViewById(R.id.btUpdate);

        edCarplate = (EditText) findViewById(R.id.edcarplatenumber);
        edNewName = (EditText) findViewById(R.id.ednewname);

//Call method for running
        UpdateData();


    }
    public void UpdateData(){
        btUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                int temp = edCarplate.getText().toString().length();

                if(temp > 0){

                    boolean update = db.updateData(edNewName.getText().toString(),edCarplate.getText().toString());
                    if((update == true)){

                        Toast.makeText(UpdateName.this,"CHECK YOUR DATA",Toast.LENGTH_LONG).show();

                        Intent backProfile = new Intent(UpdateName.this, Profile.class);
                        startActivity(backProfile);
                    } else {
                        Toast.makeText(UpdateName.this, "Something went wrong", Toast.LENGTH_LONG).show();
                    }
                }
                Toast.makeText(UpdateName.this,"You Must enter id to update",Toast.LENGTH_LONG).show();
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.goback, menu);
        return true;
    }


    /// MENU ACTION
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_goback) {
            Intent goHome = new Intent(getApplicationContext(), Home.class);
            startActivity(goHome);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
