package com.example.levantuan.projectfinal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdatePassword extends AppCompatActivity {
    DBHelper db;

    Button btchange;
    EditText edcfpassword, edNewpassword, edcarplate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_password);


        db = new DBHelper(this);

        btchange = (Button) findViewById(R.id.btchangepw);

        edcarplate = (EditText) findViewById(R.id.editcarplate);
        edNewpassword = (EditText) findViewById(R.id.newPW);
        edcfpassword = (EditText) findViewById(R.id.newcfPW);

//Call method for running
        UpdatePass();


    }
    public void UpdatePass(){
        btchange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // check if not match
                if ((edNewpassword.getText().toString()).equals(edcfpassword.getText().toString())) {

                    //Change pass word
                    int pass = edcarplate.getText().toString().length();


                    if (pass > 0) {
                        boolean update = db.updatePassword(edNewpassword.getText().toString(), edcfpassword.getText().toString(), edcarplate.getText().toString());
                        if ((update == true)) {

                            Toast.makeText(UpdatePassword.this, "CHECK YOUR DATA", Toast.LENGTH_LONG).show();

                            Intent backProfile = new Intent(UpdatePassword.this, Profile.class);
                            startActivity(backProfile);
                        } else {
                            Toast.makeText(UpdatePassword.this, "Something went wrong", Toast.LENGTH_LONG).show();
                        }
                    } else

                        Toast.makeText(UpdatePassword.this, "You Must enter Car Plate Number to update", Toast.LENGTH_LONG).show();
                }
                    else Toast.makeText(UpdatePassword.this, "Password does not match", Toast.LENGTH_SHORT).show();
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.goback, menu);
        return true;
    }


    /// MENU ACTION
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_goback) {
            Intent goHome = new Intent(getApplicationContext(), Home.class);
            startActivity(goHome);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}