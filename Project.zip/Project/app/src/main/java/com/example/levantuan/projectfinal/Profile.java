package com.example.levantuan.projectfinal;

import android.content.Intent;
import android.database.Cursor;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Profile extends AppCompatActivity {
    DBHelper db;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);



        ListView listView = (ListView) findViewById(R.id.listview);
        db = new DBHelper(this);


        // Array removing data from DATABSE
        ArrayList<String> thelist = new ArrayList<>();
        Cursor data = db.getProfiles();

        if (data.getCount() == 0) {
            Toast.makeText(Profile.this, "The database was empty :(", Toast.LENGTH_LONG).show();
        } else {

            while (data.moveToNext()) {


                thelist.add(data.getString(0));
                thelist.add(data.getString(1));
                thelist.add(data.getString(2));
                thelist.add(data.getString(4));
                thelist.add(data.getString(5));
                thelist.add(data.getString(6));
                thelist.add(data.getString(7));

                ListAdapter listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, thelist);
                listView.setAdapter(listAdapter);


            }


        }


        // ACTION FOR PARTICULAR LIST....

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position == 0) {
                    Intent goUpdateName = new Intent(Profile.this, UpdateName.class);
                    startActivity(goUpdateName);
                }
                if (position == 1) {
                    Toast.makeText(Profile.this, "Can not channge Email", Toast.LENGTH_LONG).show();

                }
                if (position == 2) {
                    Intent goUpdatePass = new Intent(Profile.this, UpdatePassword.class);
                    startActivity(goUpdatePass);
                }

                if (position == 4) {
                    Toast.makeText(Profile.this, "Can not channge Car Plate Number", Toast.LENGTH_LONG).show();
                }
                if (position == 5) {
                    Toast.makeText(Profile.this, "Can not channge Birth Date", Toast.LENGTH_LONG).show();

                }
                if (position == 6) {

                }
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.goback, menu);
        return true;
    }


    /// MENU ACTION
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_goback) {
            Intent goHome = new Intent(getApplicationContext(), Home.class);
            startActivity(goHome);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


}
