package com.example.levantuan.projectfinal;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends AppCompatActivity{



    EditText e1,e2;
    Button b1;
    Button b2;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);



        db = new DBHelper(this);

        e1 = (EditText)findViewById(R.id.EDITEMAIL);
        e2 = (EditText)findViewById(R.id.EDITPASSWORD);

        b2 = (Button)findViewById(R.id.btREGISTER);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = e1.getText().toString();
                String a = e2.getText().toString();

                Intent goRegister = new Intent(Login.this, Register.class);
                startActivity(goRegister);
            }
        });



        b1 = (Button) findViewById(R.id.btLOGIN);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = e1.getText().toString();
                String password = e2.getText().toString();




                Boolean chkemailpass = db.emailPassword(email, password);
                if (chkemailpass == true) {


                    Intent goHome = new Intent(Login.this, Home.class);

                    startActivity(goHome);

                    Toast.makeText(getApplicationContext(), "Successfully Login", Toast.LENGTH_LONG).show();


                } else
                    Toast.makeText(getApplicationContext(), "wrong email or password", Toast.LENGTH_LONG).show();
            }
        });


    }



}
